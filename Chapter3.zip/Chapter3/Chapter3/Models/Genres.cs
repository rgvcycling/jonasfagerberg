﻿using System;
namespace Chapter3.Models
{
    public enum Genres
    {
        None,
        Horror,
        Comedy,
        Romance,
        Action
    }
}
